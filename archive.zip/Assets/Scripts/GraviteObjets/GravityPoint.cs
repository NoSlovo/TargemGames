using UnityEngine;

public class GravityPoint : MonoBehaviour
{
}
